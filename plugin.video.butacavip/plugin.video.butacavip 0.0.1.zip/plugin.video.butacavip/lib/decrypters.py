# -*- coding: utf-8 -*-
import re
from platformcode import logger # CORREGIDO AQUÍ

def decode_decipher(crypto, bytes_key):
    try:
        from lib.pyberishaes import GibberishAES
        return GibberishAES.dec(GibberishAES(), string=crypto, pass_=bytes_key)
    except Exception as e:
        logger.error("Error en decode_decipher: %s" % str(e))
        return ""

def decode_js_packed(data):
    if 'eval(function(p,a,c,k,e,d)' in data:
        try:
            from lib import jsunpack
            return jsunpack.unpack(data)
        except:
            logger.error("Error: jsunpack.py no encontrado en carpeta lib")
    return data

def decode_allmyvideos(data):
    from core import scrapertools
    return scrapertools.find_single_match(data, '"file"\s*:\s*"([^"]+)"')

def decode_vidto(data):
    from core import scrapertools
    return scrapertools.find_single_match(data, 'sources\s*:\s*\["([^"]+)"')

def decode_vdownload(data):
    from core import scrapertools
    matches = scrapertools.find_multiple_matches(data, 'href="([^"]+)"[^>]+>Download')
    return matches[0] if matches else ""
