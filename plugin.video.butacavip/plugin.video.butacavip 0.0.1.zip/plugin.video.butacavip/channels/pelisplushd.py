# -*- coding: utf-8 -*-
# Placeholder para pelisplushd (Canal desactivado o pendiente de reparación)

# [OPTIMIZADO] from core import scrapertools -> Movido a funciones
from core.item import Item

def mainlist(item):
    from core import scrapertools
    return []

# def search(item, texto):
    return []